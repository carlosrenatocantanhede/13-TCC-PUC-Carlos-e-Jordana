
## --- TCC --

# -- Alterando o nome das colunas para melhorar a execucao dos comandos
atributos <- c("Country","Reproductive_Health_Act","General_Medical_Health_Act",
               "Constitution","Criminal_Penal_Code","Civil_Code","Ministerial_Orders_Decrees",
               "Case_Law","Health_Regulation_Clinical_Guideline","EML_Registered_List",
               "Medical_Ethics_Code","Document_relating_Funding","Abortion_Specific_Law",
               "Law_Medical_Practitioners","Law_Health_Care_Services","Other")
colnames(sources) <- atributos
## --Substituindo os valores das colunas para 0 e 1
sources$Reproductive_Health_Act[is.na(sources$Reproductive_Health_Act)] <- 0 
sources$Reproductive_Health_Act[sources$Reproductive_Health_Act == "X"] <- 1 

sources$General_Medical_Health_Act[is.na(sources$General_Medical_Health_Act)] <- 0 
sources$General_Medical_Health_Act[sources$General_Medical_Health_Act == "X"] <- 1 

sources$Constitution[is.na(sources$Constitution)] <- 0 
sources$Constitution[sources$Constitution == "X"] <- 1 

sources$Criminal_Penal_Code[is.na(sources$Criminal_Penal_Code)] <- 0 
sources$Criminal_Penal_Code[sources$Criminal_Penal_Code == "X"] <- 1 

sources$Civil_Code[is.na(sources$Civil_Code)] <- 0 
sources$Civil_Code[sources$Civil_Code == "X"] <- 1 

sources$Ministerial_Orders_Decrees[is.na(sources$Ministerial_Orders_Decrees)] <- 0 
sources$Ministerial_Orders_Decrees[sources$Ministerial_Orders_Decrees == "X"] <- 1 

sources$Case_Law[is.na(sources$Case_Law)] <- 0 
sources$Case_Law[sources$Case_Law == "X"] <- 1 

sources$Health_Regulation_Clinical_Guideline[is.na(sources$Health_Regulation_Clinical_Guideline)] <- 0 # substitutindo a letra B por A
sources$Health_Regulation_Clinical_Guideline[sources$Health_Regulation_Clinical_Guideline == "X"] <- 1 # substitutindo a letra B por A

sources$EML_Registered_List[is.na(sources$EML_Registered_List)] <- 0 # substitutindo a letra B por A
sources$EML_Registered_List[sources$EML_Registered_List == "X"] <- 1 # substitutindo a letra B por A

sources$Medical_Ethics_Code[is.na(sources$Medical_Ethics_Code)] <- 0 # substitutindo a letra B por A
sources$Medical_Ethics_Code[sources$Medical_Ethics_Code == "X"] <- 1 # substitutindo a letra B por A

sources$Document_relating_Funding[is.na(sources$Document_relating_Funding)] <- 0 # substitutindo a letra B por A
sources$Document_relating_Funding[sources$Document_relating_Funding == "X"] <- 1 # substitutindo a letra B por A

sources$Abortion_Specific_Law[is.na(sources$Abortion_Specific_Law)] <- 0 # substitutindo a letra B por A
sources$Abortion_Specific_Law[sources$Abortion_Specific_Law == "X"] <- 1 # substitutindo a letra B por A

sources$Law_Medical_Practitioners[is.na(sources$Law_Medical_Practitioners)] <- 0 # substitutindo a letra B por A
sources$Law_Medical_Practitioners[sources$Law_Medical_Practitioners == "X"] <- 1 # substitutindo a letra B por A

sources$Law_Health_Care_Services[is.na(sources$Law_Health_Care_Services)] <- 0 # substitutindo a letra B por A
sources$Law_Health_Care_Services[sources$Law_Health_Care_Services == "X"] <- 1 # substitutindo a letra B por A

sources$Other[is.na(sources$Other)] <- 0 # substitutindo a letra B por A
sources$Other[sources$Other == "X"] <- 1 # substitutindo a letra B por A

sources$Grupos <- 0


# -- Removendo pa�?ses duplicados #
install.packages("stringr")
library(stringr)
library(stringi)
i = 0;

while (i != nrow(sources))
{
  if ( stri_detect_fixed(sources[i,1]," - ")){
    sources[i, 1] <- sub("\\ -.*", "", sources[i, 1])
  }
  i<- i+1
}

#Ordenando as linhas pelo maior valor absoluto
sources <- sources[order(sources$Country, 
                         -abs(as.integer(sources$Reproductive_Health_Act)),
                         -abs(as.integer(sources$General_Medical_Health_Act)),
                         -abs(as.integer(sources$Constitution)),
                         -abs(as.integer(sources$Criminal_Penal_Code)),
                         -abs(as.integer(sources$Civil_Code)),
                         -abs(as.integer(sources$Ministerial_Orders_Decrees)),
                         -abs(as.integer(sources$Case_Law)),
                         -abs(as.integer(sources$Health_Regulation_Clinical_Guideline)),
                         -abs(as.integer(sources$EML_Registered_List)),
                         -abs(as.integer(sources$Medical_Ethics_Code)),
                         -abs(as.integer(sources$Document_relating_Funding)),
                         -abs(as.integer(sources$Abortion_Specific_Law)),
                         -abs(as.integer(sources$Law_Medical_Practitioners)),
                         -abs(as.integer(sources$Law_Health_Care_Services)),
                         -abs(as.integer(sources$Other))), ] ### sort first


# -- Buscando todos os valores de localidades
j=1

while (j != nrow(sources))
{
  l<-j+1
  while (sources[j,1] == sources[l,1]) {
    
    for (k in 2:length(sources) )
    {
      if (sources[l,k] > 0){
        sources[j,k]<- 1
      }
      
    } #fim do for valores da linha
    
    sources <- sources[-c(l),]
    
  }# Fim do while pa�?s duplicado
  
  j<-j+1
}

# - escolhendo o numero de clusteres:
install.packages("cluster")
library(cluster)
hc <- hclust(dist(Protein[,-1]), method = 'average')
plot(hc)

# -- avaliando a quantidade de clusters visualizando com a curva
rect.hclust(hc, k=4, border="purple")

# -- assumindo 3 clusters:
clusterCut <- cutree(hc, 3)

## -- Plotando os clusters e seus componentes --
clusplot(Protein[,-1], clusterCut,
         main='Representação Gráfica 2D - Solução
         com 3 Clusters',
         color=TRUE, shade=TRUE, labels=2,
         lines=0)

# -- Verificando quais pa�?ses ficaram em quais clusters --

modelo<-hclust(dist(sources[-1]))
sources$Grupos<-cutree(modelo, 7)
plot(modelo, labels=sources$Country, main = "Avaliação de Cluster")
rect.hclust(modelo, 7)

Pais_ordenado <- sources[order(sources$Grupos),]
grupo_pais <- subset(Pais_ordenado,select = c(Country, Grupos))
View(grupo_pais)


## -- Avaliando o número de óbitos --#
# -- Carregando a tabela com os de-para de pa�?ses e códigos
HFA_82_EN_Countries <- HFA_82_EN
# - Removendo as colunas de Mesure code e Sex
HFA_82_EN <- subset(HFA_82_EN,select = c(COUNTRY_REGION, YEAR, VALUE))

# Criando a coluna Country
HFA_82_EN$Country <- NA

# -- Ordenando a lista de codigo de paises
HFA_82_EN <- HFA_82_EN[order(HFA_82_EN$COUNTRY_REGION), ]
# -- Ordenando a amostar de número de óbitos por codigo de paises
HFA_82_EN_Countries <- HFA_82_EN_Countries[order(HFA_82_EN_Countries$Code), ]

# -- Incluindo o nome do pa�?s da tabela de amostras
j=1

while (j <= nrow(HFA_82_EN_Countries))
{ 
  for (k in 1:nrow(HFA_82_EN)) {
    
    if(stri_cmp_eq(HFA_82_EN_Countries[j,1],HFA_82_EN[k,1])){
      HFA_82_EN[k,"Country"] <-HFA_82_EN_Countries[j,"Short name"] 
    }
    
  }# Fim do while tabela de medidas
  j<-j+1
}

#removendo as linhas que não são referentes a um pa�?s
HFA_82_EN <- filter(HFA_82_EN, !is.na(Country))

sources2018 <- sources
sources2018$obitos2018 <- NA

HFA_82_EN <- HFA_82_EN[order(HFA_82_EN$Country,HFA_82_EN$YEAR), ] ### sort first


#Exportando os datasets para excel
install.packages("rJava")
install.packages("writexl")
library(writexl)
write_xlsx(sources, "c:/users/jordana/Documents/13 Trabalho de conclusao ed curso/sources.xlsx")
write_xlsx(HFA_82_EN, "c:/users/jordana/Documents/13 Trabalho de conclusao ed curso/HFA_82_EN.xlsx")

#
obitosBrasil <- data.frame(matrix(ncol=2,nrow=0, dimnames=list(NULL, c("Ano", "Valor"))))

setwd("C:/Users/jordana/Documents/13 Trabalho de conclusao ed curso/DB/DataSus")
lista <- list.files("C:/Users/jordana/Documents/13 Trabalho de conclusao ed curso/DB/DataSus", pattern="*.csv")
for (k in 1:length(lista)){
  print(k)
  obitosBrasil[k,"Ano"] <- str_remove((read.csv(file = lista[k], sep = ";", as.is = 1)[2, 1]), pattern = "Per�odo:")
  obitosBrasil[k, 2] <- str_conv(read.csv(file = lista[k], sep = ";")[9, 7], encoding="UTF-8")
  print(read.csv(file = lista[k], sep = ";")[9, 7])
}
write_xlsx(obitosBrasil, "c:/users/jordana/Documents/13 Trabalho de conclusao ed curso/obitosBrasil.xlsx")